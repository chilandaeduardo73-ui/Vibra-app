const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const required = [
  "server.js",
  "db.js",
  "package.json",
  "public/index.html",
  "public/manifest.json"
];

let failed = 0;
for (const file of required) {
  const ok = fs.existsSync(path.join(root, file));
  console.log(`${ok ? "PASS" : "FAIL"} ${file}`);
  if (!ok) failed++;
}

const pkg = require(path.join(root, "package.json"));
for (const dep of ["express", "pg"]) {
  const ok = Boolean(pkg.dependencies?.[dep]);
  console.log(`${ok ? "PASS" : "FAIL"} dependency:${dep}`);
  if (!ok) failed++;
}

const server = fs.readFileSync(path.join(root, "server.js"), "utf8");
const db = fs.readFileSync(path.join(root, "db.js"), "utf8");

for (const [label, source, needle] of [
  ["health route", server, "/api/health"],
  ["db status route", server, "/api/db-status"],
  ["database module", server, "vibraDB"],
  ["postgres pool", db, "new Pool"],
  ["local fallback", db, "data.json"]
]) {
  const ok = source.includes(needle);
  console.log(`${ok ? "PASS" : "FAIL"} ${label}`);
  if (!ok) failed++;
}

process.exit(failed ? 1 : 0);
