const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const pkg = require(path.join(root, "package.json"));

const checks = [
  ["package.json", fs.existsSync(path.join(root, "package.json"))],
  ["server.js", fs.existsSync(path.join(root, "server.js"))],
  ["public/index.html", fs.existsSync(path.join(root, "public/index.html"))],
  ["public/manifest.json", fs.existsSync(path.join(root, "public/manifest.json"))],
  ["pg dependency", Boolean(pkg.dependencies?.pg)],
  ["express dependency", Boolean(pkg.dependencies?.express)]
];

let failed = 0;
for (const [name, ok] of checks) {
  console.log(`${ok ? "PASS" : "FAIL"} ${name}`);
  if (!ok) failed++;
}

const production = process.env.NODE_ENV === "production";
if (production) {
  const db = Boolean(process.env.DATABASE_URL);
  const secret = Boolean(process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 32);
  console.log(`${db ? "PASS" : "FAIL"} DATABASE_URL in production`);
  console.log(`${secret ? "PASS" : "FAIL"} SESSION_SECRET (32+ chars) in production`);
  if (!db || !secret) failed++;
} else {
  console.log("INFO production secrets not required for local preflight");
}

process.exit(failed ? 1 : 0);
